
library(tidyverse)

train <- read.csv("train.csv")
test <- read.csv("test.csv")

# check for missing values
colSums(is.na(train))


# check for anomalies

train_ids <- unique(train$BATTER_UID)
test_ids <- unique(test$BATTER_UID)
match_found <- 0
for(i in 1:length(test_ids)){
  if(test_ids[i] %in% train_ids){
    match_found <- 1
  }
}
match_found
# the batters in the train/test set are different
# I will drop this variable


summary(train$AVG)
summary(train$OBP)
summary(train$SLG)

length(unique(train$VENUE_KEY))
# 31 - potentially Toronto multiple locations or neutral site games

table(train$OUTS)

table(train$BALLS)
table(train$STRIKES)
# there is one PA marked with 4 balls and one with 3 strikes
# with no other info about potential error with these rows I will drop them

table(train$BATS_LEFT)
table(train$THROWS_LEFT)
# combine these into one variable indicating platoon matchup

table(train$PITCH_NUMBER)

summary(train$RELEASE_SPEED)
summary(train$PLATE_X)
summary(train$PLATE_Z)
summary(train$INDUCED_VERTICAL_BREAK)
summary(train$HORIZONTAL_BREAK)
summary(train$VERTICAL_APPROACH_ANGLE)
summary(train$HORIZONTAL_APPROACH_ANGLE)

summary(train$EXIT_SPEED)
# current record for hardest hit ball is 122.2 mph
# I will drop the two rows with EV > 128

summary(train$ANGLE)
summary(train$DIRECTION)

table(train$EVENT_RESULT_KEY)
table(train$PITCH_RESULT_KEY)
# since we are only looking for balls in play, I will drop all results other than 'InPlay'
# each of these points have contact info so there must be an issue

table(train$PA)
table(train$X1B)
table(train$X2B)
table(train$X3B)
table(train$HR)
unique(rowSums(train[25:28]))

# since not available in test data, the following variables will be dropped for training:
# EXIT_SPEED, ANGLE, DIRECTION, EVENT_RESULT_KEY, PITCH_RESULT_KEY, PA

# also add in 'other' as 5th possibility category

# make adjustments:

train_cleaned <- train %>%
  filter(BALLS < 4, STRIKES < 3, EXIT_SPEED < 128, PITCH_RESULT_KEY == "InPlay") %>%
  mutate(platoon = ifelse(BATS_LEFT == 1,
                          ifelse(THROWS_LEFT == 1, "LL", "RL"),
                          ifelse(THROWS_LEFT == 1, "LR", "RR")),
         result = ifelse(X1B == 1, "single",
                  ifelse(X2B == 1, "double",
                  ifelse(X3B == 1, "triple",
                  ifelse(HR == 1, "homerun", "other"))))) %>%
  select(-BATTER_UID, -EXIT_SPEED, -ANGLE, -DIRECTION, -EVENT_RESULT_KEY, -PITCH_RESULT_KEY,
         -PA, -X1B, -X2B, -X3B, -HR, -BATS_LEFT, -THROWS_LEFT)
  
test_cleaned <- test %>%
  mutate(platoon = ifelse(BATS_LEFT == 1,
                          ifelse(THROWS_LEFT == 1, "LL", "RL"),
                          ifelse(THROWS_LEFT == 1, "LR", "RR"))) %>%
  select(-BATTER_UID, -BATS_LEFT, -THROWS_LEFT)

# save

write.csv(train_cleaned, file = "train_cleaned.csv", row.names = F)
write.csv(test_cleaned, file = "test_cleaned.csv", row.names = F)
